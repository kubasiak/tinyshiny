
# setwd("./DataCollection")
source("global.R")
function(input,output,session){
  
  alldata<-cleanData()
  idx<-alldata[[1]]
  
  idx2<-cleanData2()[[1]]
  
  # var<-alldata[[2]]
  # attr<-alldata[[3]]
  # idxGroup<-alldata[[4]]
  
  allSelected<-reactive(c(input$indexSelection1,input$indexSelection2,input$indexSelection3,input$indexSelection4,input$indexSelection5,input$indexSelection6,input$indexSelection7,input$indexSelection8))
  allSelectedIdx<- reactive (idx[idx$idxName %in% allSelected(),]) 
  ownershipValues <- reactiveValues()
  
  source('Render/indexSelection1.R', local = TRUE)$value
  source('Render/indexSelection2.R', local = TRUE)$value
  source('Render/indexSelection3.R', local = TRUE)$value
  source('Render/indexSelection4.R', local = TRUE)$value
  source('Render/indexSelection5.R', local = TRUE)$value
  source('Render/indexSelection6.R', local = TRUE)$value
  source('Render/indexSelection7.R', local = TRUE)$value
  source('Render/indexSelection8.R', local = TRUE)$value
  
  
  
  output$selected=renderPrint({
    cat('Selected Indices',allSelected(),sep="\n")
  })
  
  output$selectedTable<-renderTable({
    columns=6
    values<-character()
    values<-c(allSelected(),rep("",columns-mod(length(allSelected()),columns)))
    matrix(values,ncol=columns)},include.colnames=FALSE)
  

  output$ownershipTable=renderRHandsontable({
    df<-data.frame(idxId=allSelectedIdx()$idxId,Name=allSelectedIdx()$idxName,
               # Description=allSelectedIdx()$idxDescription %>% substr(1,40),
               Group=allSelectedIdx()$idxGroup)
    ROnames<-names(df)
   
    if(file.exists("Data/Owners.csv")){
      print('file Exists')
      ownerTableFromFile<-read.csv("Data/Owners.csv",sep=";",stringsAsFactors = FALSE)
      df<-merge(df,ownerTableFromFile[,c('idxId','Owner')], by='idxId',all.x=TRUE)
      df$Owner[is.na(df$Owner)]<-""
    }else{
    df$Owner<-rep("",nrow(allSelectedIdx()))
    }
    rhandsontable(df,selectCallback = TRUE,readOnly = FALSE)%>%
      hot_col(ROnames, readOnly = TRUE) 
  })

  
  output$description=renderPrint({
    thisrow<-input$ownershipTable_select$select$r
    thisIndex<-allSelectedIdx()$idxName[thisrow]
    thisDescription<-allSelectedIdx()$idxDescription[thisrow]
    cat(thisIndex,'\n',thisDescription)
  })
  
  observeEvent(input$saveOwners,{
    DF<-hot_to_r(input$ownershipTable)
    write.table(DF,"Data/Owners.csv",sep=";",row.names=FALSE)
  })
  
  
} # end server


######################################

# test_case <- hot_to_r(input$all_updates)


