header <- dashboardHeader(
  title = "Tool"
)
# source("UI/tags.R")$value
source("UI/sidebar.R")

source("UI/tabItem_Title.R")
source("UI/tabItem_IndexSelection.R")
source("UI/tabItem_Owners.R")
 # source("UI/tabItem_G4selection.R")

body <- dashboardBody(
  
  tabItems(
    tabItem_Title,
    tabItem_IndexSelection,
    tabItem_Owners
  )  
)

dashboardPage(
  header,
  sidebar,
  body
)
