indexList5<-  as.character(idx$idxName[idx$idxGroupId==5])
indexDescription5<- as.character(idx$idxDescription[idx$idxGroupId==5] )

output$indexSelection5<-renderUI({
  list(
    checkboxGroupInput("indexSelection5",
                       tags$span("Please Select",   
                                 tipify(bsButton("idx5", "?", style = "inverse", size = "extra-small"), "Group 5")),
                       choices=indexList5,selected=indexList5) ,
    makeCheckboxTooltip(checkboxValue=indexList5,buttonLabel=rep("?"),Tooltip=indexDescription5)
    
  )
})