indexList8<-  as.character(idx$idxName[idx$idxGroupId==8])
indexDescription8<- as.character(idx$idxDescription[idx$idxGroupId==8] )

output$indexSelection8<-renderUI({
  list(
    checkboxGroupInput("indexSelection8",
                       tags$span("Please Select",   
                                 tipify(bsButton("idx8", "?", style = "inverse", size = "extra-small"), "Group 8")),
                       choices=indexList8,selected=indexList8) ,
    makeCheckboxTooltip(checkboxValue=indexList8,buttonLabel=rep("?"),Tooltip=indexDescription8)
    
  )
})