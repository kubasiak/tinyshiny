indexList1<-  as.character(idx$idxName[idx$idxGroupId==1])
indexDescription1<- as.character(idx$idxDescription[idx$idxGroupId==1] )

output$indexSelection1<-renderUI({
  list(
    checkboxGroupInput("indexSelection1",
                       tags$span("Please Select",   
                                 tipify(bsButton("idx1", "?", style = "inverse", size = "extra-small"), "Group 1")),
                       choices=indexList1,selected=indexList1) ,
    makeCheckboxTooltip(checkboxValue=indexList1,buttonLabel=rep("?"),Tooltip=indexDescription1)
    
  )
})