indexList2<-  as.character(idx$idxName[idx$idxGroupId==2])
indexDescription2<- as.character(idx$idxDescription[idx$idxGroupId==2] )
output$indexSelection2<-renderUI({
  list(
    checkboxGroupInput("indexSelection2",
                       tags$span("Please Select",   
                                 tipify(bsButton("idx2", "?", style = "inverse", size = "extra-small"), "Group 2")),
                       choices=indexList2,selected=indexList2),
    makeCheckboxTooltip(checkboxValue=indexList2,buttonLabel=rep("?"),Tooltip=indexDescription2)
    
  )
})