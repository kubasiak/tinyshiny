indexList3<-  as.character(idx$idxName[idx$idxGroupId==3])
indexDescription3<- as.character(idx$idxDescription[idx$idxGroupId==3] )
output$indexSelection3<-renderUI({
  list(
    checkboxGroupInput("indexSelection3",
                       tags$span("Please Select",   
                                 tipify(bsButton("idx3", "?", style = "inverse", size = "extra-small"), "Group 3")),
                       choices=indexList3,selected=indexList3),
    makeCheckboxTooltip(checkboxValue=indexList3,buttonLabel=rep("?"),Tooltip=indexDescription3)
    
  )
})