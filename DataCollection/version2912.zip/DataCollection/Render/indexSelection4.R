indexList4<-  as.character(idx$idxName[idx$idxGroupId==4])
indexDescription4<- as.character(idx$idxDescription[idx$idxGroupId==4] )

output$indexSelection4<-renderUI({
  list(
    checkboxGroupInput("indexSelection4",
                       tags$span("Please Select",   
                                 tipify(bsButton("idx4", "?", style = "inverse", size = "extra-small"), "Group 4")),
                       choices=indexList4,selected=indexList4) ,
    makeCheckboxTooltip(checkboxValue=indexList4,buttonLabel=rep("?"),Tooltip=indexDescription4)
    
  )
})