indexList6<-  as.character(idx$idxName[idx$idxGroupId==6])
indexDescription6<- as.character(idx$idxDescription[idx$idxGroupId==6] )

output$indexSelection6<-renderUI({
  list(
    checkboxGroupInput("indexSelection6",
                       tags$span("Please Select",   
                                 tipify(bsButton("idx6", "?", style = "inverse", size = "extra-small"), "Group 6")),
                       choices=indexList6,selected=indexList6) ,
    makeCheckboxTooltip(checkboxValue=indexList6,buttonLabel=rep("?"),Tooltip=indexDescription6)
    
  )
})