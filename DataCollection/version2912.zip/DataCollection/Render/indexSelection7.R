indexList7<-  as.character(idx$idxName[idx$idxGroupId==7])
indexDescription7<- as.character(idx$idxDescription[idx$idxGroupId==7] )

output$indexSelection7<-renderUI({
  list(
    checkboxGroupInput("indexSelection7",
                       tags$span("Please Select",   
                                 tipify(bsButton("idx7", "?", style = "inverse", size = "extra-small"), "Group 7")),
                       choices=indexList7,selected=indexList7) ,
    makeCheckboxTooltip(checkboxValue=indexList7,buttonLabel=rep("?"),Tooltip=indexDescription7)
    
  )
})